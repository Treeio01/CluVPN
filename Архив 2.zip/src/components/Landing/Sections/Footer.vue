<template>
    <div class="flex  max-w-[370px] mobile:max-w-[916px] 1025:max-w-[1275px]  flex-col gap-[21px] mobile:gap-[96px] w-full mt-[57px]  pt-[48px]">
        <div class="flex items-start gap-4 mobile:gap-[98px] w-full max-w-[1275px]">
            <img src="../../../assets/img/logo.svg" alt="">
            <div class="flex flex-col gap-4 w-full">
                <a class="text-white mobile:text-left text-right min-h-[31px] font-Inter font-semibold text-sm leading-[20px] tracking-0">
                    Контакты
                </a>
                <a class="text-white mobile:text-left text-right font-Inter min-h-[20px] text-sm leading-[20px] tracking-0">
                    Поддержка
                </a>
                <a class="text-white mobile:text-left text-right font-Inter min-h-[20px] text-sm leading-[20px] tracking-0">
                    Пиар-отдел
                </a>
                <a class="text-white mobile:text-left text-right font-Inter min-h-[20px] text-sm leading-[20px] tracking-0">
                    Электронная почта
                </a>
            </div>
        </div>
        <div class="flex mobile:flex-row flex-col items-start mobile:items-center justify-between pt-4 w-full border-t border-white/10">
            <span class="text-[12px] text-white font-Inter leading-[16px] tracking-0">
                © 2025 CLU VPN. Все права защищены
            </span>
            <div class="flex items-center mobile:gap-4 gap-16 ">
                <span class="text-[12px] text-white font-Inter leading-[16px] tracking-0">
                    Политика конфиденциальности
                </span>
                <span class="text-[12px] text-white font-Inter leading-[16px] tracking-0">
                    Договор оферта
                </span>
            </div>
        </div>
    </div>
</template>
<script setup>
</script>