<template>
    <div id="advantages" class="flex mt-[80px] mobile:text-left text-center 1025:mt-[109px] flex-col gap-[35px] mobile:gap-[75px] 1025:gap-[86px] w-full px-[25px] mobile:px-[44px] 1025:max-w-[1275px] ">
        <span class="text-white font-Golos font-semibold text-[19px] mobile:text-[35px] 1025:text-[40px] leading-[19px]">
            <span class="text-primary">
                Преимущества
            </span> над другими VPN
        </span>
        <div class="flex flex-col w-full">
            <div class="flex w-full items-center border-b border-[#696969]">
                <div class="flex py-[38px]  w-full max-w-[694px] min-w-[144px]">
                    <span class="text-white font-Golos text-[16px] mobile:text-[27px] 1025:text-[30px] font-bold  leading-[18px] mobile:leading-[30px]">
                        Сравнение
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <img src="../../../assets/img/logo.svg" alt="">
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-white font-Golos text-sm mobile:text-[28px] 1025:text-[35px] font-bold  leading-[18px] mobile:leading-[30px]">
                        Другие VPN
                    </span>
                </div>
            </div>
            <div class="flex w-full items-center border-b border-[#696969]">
                <div class="flex py-[38px]  w-full max-w-[694px] min-w-[144px]">
                    <span class="text-white font-Golos text-[16px] mobile:text-[27px] 1025:text-[30px] font-bold  leading-[18px] mobile:leading-[30px]">
                        Ограничение по устройствам
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-primary font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px]">
                        Без лимита
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-[#C8C8C8]/85 font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px] mobile:leading-[30px]">
                        До 3 устройств
                    </span>
                </div>
            </div>
            
            <div class="flex w-full items-center border-b border-[#696969]">
                <div class="flex py-[38px]  w-full max-w-[694px] min-w-[144px]">
                    <span class="text-white font-Golos text-[16px] mobile:text-[27px] 1025:text-[30px] font-bold  leading-[18px] mobile:leading-[30px]">
                       Ограничение по трафику
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-primary font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px]">
                        Без лимита
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-[#C8C8C8]/85 font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px] mobile:leading-[30px]">
                        До 10ГБ
                    </span>
                </div>
            </div>
            
            <div class="flex w-full items-center border-b border-[#696969]">
                <div class="flex py-[38px]  w-full max-w-[694px] min-w-[144px]">
                    <span class="text-white font-Golos text-[16px] mobile:text-[27px] 1025:text-[30px] font-bold  leading-[18px] mobile:leading-[30px]">
                       Поддерживаемые устройства
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-primary font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px]">
                        Все устройства
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-[#C8C8C8]/85 font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px] mobile:leading-[30px]">
                       IOS, Android
                    </span>
                </div>
            </div>
            
            <div class="flex w-full items-center">
                <div class="flex py-[38px]  w-full max-w-[694px] min-w-[144px]">
                    <span class="text-white font-Golos text-[16px] mobile:text-[27px] 1025:text-[30px] font-bold  leading-[18px] mobile:leading-[30px]">
                      Техническая поддержка
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-primary text-center font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px] mobile:leading-[30px]">
                        Команда специалистов
                    </span>
                </div>
                <div class="flex justify-center py-[20px] mobile:py-[38px] px-[5px] mobile:px-[31px] w-full max-w-[280px]">
                    <span class="text-[#C8C8C8]/85 font-Golos text-[12px] mobile:text-[20px] 1025:text-[28px] 1025:font-semibold leading-[18px] mobile:leading-[30px]">
                       Отсутствует
                    </span>
                </div>
            </div>
        </div>
    </div>
</template>
<script setup>
</script>