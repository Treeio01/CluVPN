<template>
  <div
    class="flex w-full relative max-w-[1440px] flex-col py-[59px] mobile:py-[50px] 1025:py-[140px] pb-[28px] px-[30px] mobile:px-[53px] 1025:px-[85px]">
    <img src="../../../assets/img/mobile.png" class="max-w-[462px] hidden 1240:flex absolute right-[76px] top-[50px]"
      alt="" />

    <div class="flex flex-col gap-[5px] mobile:gap-[30px] max-w-[761px]">
      <h1 class="text-white font-Tektur font-semibold text-[40px] mobile:text-[51px] leading-[90%] tracking-0">
        Ваш интернет на ваших правилах
      </h1>
      <span
        class="text-[#B7B7B7] font-Golos text-sm mobile:text-xl font-medium leading-[16px] mobile:leading-[28px] tracking-0 max-w-[560px]">
        Подключитесь сейчас и забудьте о блокировках и навязчивой рекламе в
        интернете
      </span>
    </div>
    <div class="flex gap-3 mobile:flex-row flex-col mobile:gap-[25px] items-center mt-[193px] mobile:mt-[45px]">
      <button
        class="bg-primary mobile:order-1 order-2 mobile:w-max w-full rounded-[20px] py-[15px] mobile:py-6 px-9 flex items-center justify-center">
        <span class="text-white font-Days text-lg leading-[20px] tracking-[-12%]">
          Купить от 200р / мес
        </span>
      </button>
      <button
        class="bg-white mobile:order-2 order-1 mobile:w-max w-full rounded-[20px] py-[15px] mobile:py-6 px-[21px] flex items-center justify-center">
        <span class="text-primary font-Days text-lg leading-[20px] tracking-[-12%]">
          Попробовать бесплатно
        </span>
      </button>
    </div>
    <div class="flex mt-[10px] mobile:mt-[34px] items-center">
      <span class="text-[#CCCCCC] font-Roboto text-[12px] mobile:text-[17px] leading-[20px] tracking-[0.07em]">
        ✔ Вернем деньги, если не оправдаем ваших ожиданий
      </span>
    </div>
    <div
      class="flex mt-[22px] mobile:mt-[65px] relative flex-col gap-[15px] mobile:gap-[11px] 1025:gap-[21px] bg-primary rounded-[20px] mobile:rounded-[40px] 1025:rounded-[60px] w-full max-w-[918px] 1025:max-w-[761px] py-[17px] mobile:py-[31px] pb-[13px] mobile:pb-[38px] px-[25px] mobile:px-[52px]">
      <img src="../../../assets/img/human.png"
        class="absolute md:flex hidden max-w-[191px] bottom-[-16px] right-[91px] 1025:right-[60px]" alt="">
      <span
        class="text-white font-Golos font-bold text-[22px] mobile:text-[41px] 1025:text-[44px] leading-[25px] tracking-0">
        Умный VPN - что это такое?
      </span>
      <span
        class="text-white font-Golos font-semibold text-[17px] 1025:text-[30px] mobile:text-[33px] leading-[17px] mobile:leading-[33px] tracking-[-0.03em] max-w-[267px] mobile:max-w-[420px]">
        об этом и многом другом рассказали дальше
      </span>
      <button class="bg-white rounded-[10px]  mobile:rounded-[20px] 1025:rounded-[25px] py-2 mobile:py-[18px] 1025:py-[23px] w-full max-w-[360px]">
        <span class="text-primary font-Inter font-bold text-[20px] mobile:text-[28px] leading-[20px] tracking-0">
          Смотреть
        </span>
      </button>
    </div>
  </div>
</template>
<script setup></script>
